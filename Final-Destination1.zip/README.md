UPDATES

28 Sep Shuqi added "Score Manager" to the app

