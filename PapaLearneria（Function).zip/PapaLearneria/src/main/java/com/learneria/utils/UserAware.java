package com.learneria.utils;

public interface UserAware {
    void setUsername(String username);
}
