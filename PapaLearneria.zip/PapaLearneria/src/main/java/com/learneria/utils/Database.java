package com.learneria.utils;

import java.sql.*;

public class Database {

    private static final String DB_URL = "jdbc:sqlite:src/main/resources/db/learneria.db";

    static {
        initialize();
    }

    /**
     * Initialize database and create users table (if not exists).
     */
    private static void initialize() {

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            // Create table if it doesn't exist
            String sql = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "username TEXT UNIQUE NOT NULL," +
                    "password TEXT NOT NULL," +
                    "role TEXT NOT NULL," +
                    "teacher_code TEXT" +
                    ")";
            stmt.execute(sql);

            System.out.println("✅ Database initialized and users table ready.");

            // Insert default test accounts if table empty
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM users");
            if (rs.next() && rs.getInt("count") == 0) {
                stmt.execute("INSERT INTO users (username, password, role) VALUES ('teststudent', '1234', 'student')");
                stmt.execute("INSERT INTO users (username, password, role) VALUES ('testteacher', '1234', 'teacher')");
                System.out.println("👤 Default test accounts created.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Get a connection to the database.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    /**
     * Validate login credentials.
     */
    public static boolean validateLogin(String username, String password, String role) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, role);

            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // true if found

        } catch (SQLException e) {
            System.out.println("⚠️ Login check failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Debug helper: print all users.
     */
    public static void printAllUsers() {
        String sql = "SELECT id, username, password, role, teacher_code FROM users";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("📋 Current users in DB:");
            while (rs.next()) {
                System.out.printf("ID: %d | Username: %s | Password: %s | Role: %s | Teacher Code: %s%n",
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("teacher_code"));
            }

        } catch (SQLException e) {
            System.out.println("⚠️ Error reading users: " + e.getMessage());
        }
    }
}
