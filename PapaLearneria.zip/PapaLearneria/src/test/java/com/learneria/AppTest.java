package com.learneria;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AppTest {

    @Test
    void simpleTest() {
        // This is just a dummy test
        assertTrue(2 + 2 == 4, "Math should still work 😅");
    }
}
